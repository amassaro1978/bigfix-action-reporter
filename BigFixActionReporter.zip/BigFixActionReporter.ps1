#Requires -Version 5.1
<#
.SYNOPSIS
    BigFix Action Reporter v4 - Visual dashboard with animated Chart.js charts
.DESCRIPTION
    PowerShell/WPF GUI with embedded WebBrowser for Chart.js-powered interactive
    charts. Connects to BigFix REST API for action deployment status.
.NOTES
    Author: Anthony / thomasShartalter
    Date: 2026-02-12
#>

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms

# Force IE11 mode for WebBrowser control (needed for Chart.js)
$regPath = "HKCU:\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION"
if (-not (Test-Path $regPath)) { New-Item -Path $regPath -Force | Out-Null }
$exeName = [System.IO.Path]::GetFileName([System.Diagnostics.Process]::GetCurrentProcess().Path)
Set-ItemProperty -Path $regPath -Name $exeName -Value 11001 -Type DWord -ErrorAction SilentlyContinue

# ─── Configuration ───────────────────────────────────────────────────────────
$script:Config = @{
    ServerUrl    = ""
    Username     = ""
    Password     = ""
    ApiBase      = "/api"
}

# ─── XAML UI Definition ──────────────────────────────────────────────────────
[xml]$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="BigFix Action Reporter" Height="900" Width="1200"
        WindowStartupLocation="CenterScreen"
        Background="#0f0f1a" Foreground="#cdd6f4">

    <Window.Resources>
        <Style TargetType="Button">
            <Setter Property="Background" Value="#89b4fa"/>
            <Setter Property="Foreground" Value="#1e1e2e"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Padding" Value="16,8"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" 
                                CornerRadius="6" Padding="{TemplateBinding Padding}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Background" Value="#b4d0fb"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style TargetType="TextBox">
            <Setter Property="Background" Value="#1a1a2e"/>
            <Setter Property="Foreground" Value="#cdd6f4"/>
            <Setter Property="BorderBrush" Value="#313244"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="Padding" Value="8,6"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>
        <Style TargetType="Label">
            <Setter Property="Foreground" Value="#bac2de"/>
            <Setter Property="FontSize" Value="13"/>
        </Style>
        <Style TargetType="DataGrid">
            <Setter Property="Background" Value="#0f0f1a"/>
            <Setter Property="Foreground" Value="#cdd6f4"/>
            <Setter Property="BorderBrush" Value="#313244"/>
            <Setter Property="RowBackground" Value="#141425"/>
            <Setter Property="AlternatingRowBackground" Value="#1a1a2e"/>
            <Setter Property="GridLinesVisibility" Value="Horizontal"/>
            <Setter Property="HorizontalGridLinesBrush" Value="#232336"/>
            <Setter Property="HeadersVisibility" Value="Column"/>
            <Setter Property="FontSize" Value="12"/>
        </Style>
    </Window.Resources>

    <Grid Margin="16">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- Header with glow -->
        <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="0,0,0,12">
            <TextBlock Text="BIGFIX ACTION REPORTER" FontSize="28" FontWeight="Bold" 
                       Foreground="#89b4fa" FontFamily="Segoe UI">
                <TextBlock.Effect>
                    <DropShadowEffect Color="#89b4fa" BlurRadius="20" ShadowDepth="0" Opacity="0.5"/>
                </TextBlock.Effect>
            </TextBlock>
            <TextBlock Text="  v4" FontSize="14" Foreground="#6c7086" VerticalAlignment="Bottom" Margin="0,0,0,4"/>
        </StackPanel>

        <!-- Connection Settings -->
        <Border Grid.Row="1" Background="#141425" CornerRadius="10" Padding="14" Margin="0,0,0,10"
                BorderBrush="#232346" BorderThickness="1">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="160"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="160"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <Label Content="Server:" VerticalAlignment="Center"/>
                <TextBox x:Name="txtServer" Grid.Column="1" Margin="4,0" 
                         ToolTip="https://bigfix-server:52311"/>
                <Label Content="User:" Grid.Column="2" VerticalAlignment="Center"/>
                <TextBox x:Name="txtUser" Grid.Column="3" Margin="4,0"/>
                <Label Content="Pass:" Grid.Column="4" VerticalAlignment="Center"/>
                <PasswordBox x:Name="txtPass" Grid.Column="5" Margin="4,0"
                             Background="#1a1a2e" Foreground="#cdd6f4" 
                             BorderBrush="#313244" Padding="8,6" FontSize="14"/>
                <Button x:Name="btnConnect" Content="Connect" Grid.Column="7" Margin="8,0,0,0"/>
            </Grid>
        </Border>

        <!-- Action ID Input -->
        <Border Grid.Row="2" Background="#141425" CornerRadius="10" Padding="14" Margin="0,0,0,10"
                BorderBrush="#232346" BorderThickness="1">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="200"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <Label Content="Action ID:" VerticalAlignment="Center" FontSize="15" FontWeight="SemiBold"/>
                <TextBox x:Name="txtActionId" Grid.Column="1" Margin="4,0" FontSize="16"/>
                <Button x:Name="btnFetch" Content="Fetch Status" Grid.Column="2" Margin="8,0"/>
                <Button x:Name="btnRefresh" Content="Refresh" Grid.Column="3" Margin="4,0"
                        Background="#a6e3a1" IsEnabled="False"/>
                <Button x:Name="btnDemo" Content="Demo Data" Grid.Column="4" Margin="4,0"
                        Background="#cba6f7"/>
                <TextBlock x:Name="lblActionName" Grid.Column="5" VerticalAlignment="Center" 
                           Margin="12,0" FontSize="13" Foreground="#a6adc8" TextTrimming="CharacterEllipsis"/>
                <Button x:Name="btnExport" Content="Export CSV" Grid.Column="6" 
                        Background="#f9e2af" IsEnabled="False"/>
            </Grid>
        </Border>

        <!-- Main Content Area -->
        <Grid Grid.Row="3">
            <Grid.RowDefinitions>
                <RowDefinition Height="340"/>
                <RowDefinition Height="*"/>
            </Grid.RowDefinitions>

            <!-- Top: Charts Row (WebBrowser) -->
            <Border Grid.Row="0" Background="#141425" CornerRadius="10" Margin="0,0,0,10"
                    BorderBrush="#232346" BorderThickness="1">
                <WebBrowser x:Name="wbCharts" Margin="2"/>
            </Border>

            <!-- Bottom: Data Grid -->
            <Border Grid.Row="1" Background="#141425" CornerRadius="10" Padding="8"
                    BorderBrush="#232346" BorderThickness="1">
                <Grid>
                    <TextBlock Text="ENDPOINT DETAILS" FontSize="14" FontWeight="SemiBold" 
                               Foreground="#89b4fa" Margin="4,2,0,4" VerticalAlignment="Top"
                               FontFamily="Segoe UI"/>
                    <DataGrid x:Name="dgEndpoints" Margin="0,26,0,0" AutoGenerateColumns="False"
                              IsReadOnly="True" CanUserSortColumns="True" 
                              SelectionMode="Single">
                        <DataGrid.Columns>
                            <DataGridTextColumn Header="Computer Name" Binding="{Binding ComputerName}" Width="*"/>
                            <DataGridTextColumn Header="Status" Binding="{Binding Status}" Width="100"/>
                            <DataGridTextColumn Header="Start Time" Binding="{Binding StartTime}" Width="150"/>
                            <DataGridTextColumn Header="End Time" Binding="{Binding EndTime}" Width="150"/>
                            <DataGridTextColumn Header="Apply Count" Binding="{Binding ApplyCount}" Width="85"/>
                            <DataGridTextColumn Header="Retry Count" Binding="{Binding RetryCount}" Width="85"/>
                        </DataGrid.Columns>
                    </DataGrid>
                </Grid>
            </Border>
        </Grid>

        <!-- Status Bar -->
        <Border Grid.Row="4" Background="#141425" CornerRadius="8" Padding="10,6" Margin="0,8,0,0"
                BorderBrush="#232346" BorderThickness="1">
            <Grid>
                <TextBlock x:Name="lblStatus" Text="Ready -- Enter server details and connect" 
                           FontSize="12" Foreground="#a6adc8"/>
                <TextBlock x:Name="lblLastRefresh" Text="" FontSize="12" Foreground="#6c7086"
                           HorizontalAlignment="Right"/>
            </Grid>
        </Border>
    </Grid>
</Window>
"@

# ─── Load XAML ────────────────────────────────────────────────────────────────
$reader = New-Object System.Xml.XmlNodeReader $XAML
$window = [Windows.Markup.XamlReader]::Load($reader)

# Get all named elements
$XAML.SelectNodes("//*[@*[contains(translate(name(),'x','X'),'Name')]]") | ForEach-Object {
    Set-Variable -Name ($_.Name) -Value $window.FindName($_.Name) -Scope Script
}

# ─── Chart.js HTML Template ──────────────────────────────────────────────────

function Get-ChartHTML {
    param($StatusCounts, $Total, $TimelineData, $CompletionPct)
    
    $timelineLabels = ($TimelineData.Labels | ForEach-Object { "'$_'" }) -join ","
    $timelineValues = ($TimelineData.Values) -join ","
    
    # Determine gradient color for completion gauge
    $gaugeColor = if ($CompletionPct -ge 80) { "#a6e3a1" } 
                  elseif ($CompletionPct -ge 50) { "#f9e2af" }
                  else { "#f38ba8" }

    # Load Chart.js from bundled file or fallback
    $scriptDir = Split-Path -Parent $PSCommandPath
    $chartJsPath = Join-Path $scriptDir "chart.min.js"
    if (Test-Path $chartJsPath) {
        $chartJsCode = [System.IO.File]::ReadAllText($chartJsPath)
    } else {
        $chartJsCode = "/* chart.min.js not found - place it next to this script */"
    }

    return @"
<!-- saved from url=(0016)http://localhost -->
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<script>$chartJsCode</script>
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
        background: #141425; 
        font-family: 'Segoe UI', sans-serif; 
        color: #cdd6f4;
        overflow: hidden;
    }
    .dashboard { 
        display: flex; 
        gap: 12px; 
        padding: 12px;
        height: 100vh;
    }
    .chart-card {
        background: linear-gradient(145deg, #1a1a30, #141425);
        border: 1px solid #2a2a45;
        border-radius: 12px;
        padding: 14px;
        flex: 1;
        position: relative;
        overflow: hidden;
    }
    .chart-card::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 2px;
        background: linear-gradient(90deg, transparent, #89b4fa, transparent);
    }
    .chart-card.green::before {
        background: linear-gradient(90deg, transparent, #a6e3a1, transparent);
    }
    .chart-card.purple::before {
        background: linear-gradient(90deg, transparent, #cba6f7, transparent);
    }
    .card-title {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        color: #89b4fa;
        margin-bottom: 8px;
    }
    .chart-card.green .card-title { color: #a6e3a1; }
    .chart-card.purple .card-title { color: #cba6f7; }
    
    .gauge-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: calc(100% - 30px);
    }
    .gauge-value {
        font-size: 48px;
        font-weight: 800;
        color: ${gaugeColor};
        text-shadow: 0 0 30px ${gaugeColor}66;
        line-height: 1;
    }
    .gauge-label {
        font-size: 12px;
        color: #6c7086;
        margin-top: 4px;
        text-transform: uppercase;
        letter-spacing: 2px;
    }
    .gauge-bar {
        width: 80%;
        height: 6px;
        background: #232346;
        border-radius: 3px;
        margin-top: 12px;
        overflow: hidden;
    }
    .gauge-fill {
        height: 100%;
        width: ${CompletionPct}%;
        background: linear-gradient(90deg, #89b4fa, ${gaugeColor});
        border-radius: 3px;
        box-shadow: 0 0 12px ${gaugeColor}88;
        animation: fillGauge 1.5s ease-out;
    }
    @keyframes fillGauge {
        from { width: 0%; }
        to { width: ${CompletionPct}%; }
    }
    
    .stats-row {
        display: flex;
        gap: 6px;
        margin-top: 10px;
        flex-wrap: wrap;
        justify-content: center;
    }
    .stat-pill {
        padding: 3px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        background: #232346;
    }
    .stat-pill.fixed { color: #a6e3a1; border: 1px solid #a6e3a133; }
    .stat-pill.failed { color: #f38ba8; border: 1px solid #f38ba833; }
    .stat-pill.running { color: #f9e2af; border: 1px solid #f9e2af33; }
    .stat-pill.pending { color: #89b4fa; border: 1px solid #89b4fa33; }
    .stat-pill.notrel { color: #6c7086; border: 1px solid #6c708633; }
    .stat-pill.expired { color: #fab387; border: 1px solid #fab38733; }
    
    canvas { max-height: 100%; }
</style>
</head>
<body>
<div class="dashboard">
    <!-- Donut Chart -->
    <div class="chart-card" style="flex: 0.9;">
        <div class="card-title">Status Breakdown</div>
        <canvas id="donutChart"></canvas>
    </div>
    
    <!-- Completion Gauge -->
    <div class="chart-card purple" style="flex: 0.6;">
        <div class="card-title">Completion Rate</div>
        <div class="gauge-container">
            <div class="gauge-value">${CompletionPct}%</div>
            <div class="gauge-label">of relevant endpoints</div>
            <div class="gauge-bar"><div class="gauge-fill"></div></div>
            <div class="stats-row">
                <span class="stat-pill fixed">Fixed $($StatusCounts.Fixed)</span>
                <span class="stat-pill failed">Failed $($StatusCounts.Failed)</span>
                <span class="stat-pill running">Running $($StatusCounts.Running)</span>
                <span class="stat-pill pending">Pending $($StatusCounts.Pending)</span>
                <span class="stat-pill notrel">N/R $($StatusCounts.NotRelevant)</span>
                <span class="stat-pill expired">Expired $($StatusCounts.Expired)</span>
            </div>
        </div>
    </div>
    
    <!-- Timeline Chart -->
    <div class="chart-card green" style="flex: 1.2;">
        <div class="card-title">Completion Timeline</div>
        <canvas id="timelineChart"></canvas>
    </div>
</div>

<script>
Chart.defaults.global.defaultFontColor = '#bac2de';
Chart.defaults.global.defaultFontFamily = 'Segoe UI';

// Donut Chart
new Chart(document.getElementById('donutChart').getContext('2d'), {
    type: 'doughnut',
    data: {
        labels: ['Fixed', 'Failed', 'Running', 'Pending', 'Not Relevant', 'Expired'],
        datasets: [{
            data: [$($StatusCounts.Fixed), $($StatusCounts.Failed), $($StatusCounts.Running), $($StatusCounts.Pending), $($StatusCounts.NotRelevant), $($StatusCounts.Expired)],
            backgroundColor: [
                'rgba(166,227,161,0.85)',
                'rgba(243,139,168,0.85)',
                'rgba(249,226,175,0.85)',
                'rgba(137,180,250,0.85)',
                'rgba(108,112,134,0.85)',
                'rgba(250,179,135,0.85)'
            ],
            borderColor: [
                '#a6e3a1',
                '#f38ba8',
                '#f9e2af',
                '#89b4fa',
                '#6c7086',
                '#fab387'
            ],
            borderWidth: 2,
            hoverBorderWidth: 3
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutoutPercentage: 62,
        animation: {
            animateRotate: true,
            duration: 1200,
            easing: 'easeOutQuart'
        },
        legend: {
            position: 'bottom',
            labels: {
                padding: 12,
                usePointStyle: true,
                fontSize: 11
            }
        },
        tooltips: {
            backgroundColor: '#1e1e2e',
            titleFontColor: '#cdd6f4',
            bodyFontColor: '#bac2de',
            borderColor: '#313244',
            borderWidth: 1,
            cornerRadius: 8,
            xPadding: 10,
            yPadding: 10,
            callbacks: {
                label: function(tooltipItem, data) {
                    var value = data.datasets[0].data[tooltipItem.index];
                    var label = data.labels[tooltipItem.index];
                    var pct = (value / ${Total} * 100).toFixed(1);
                    return ' ' + label + ': ' + value + ' (' + pct + '%)';
                }
            }
        }
    }
});

// Timeline Chart  
var timeCtx = document.getElementById('timelineChart').getContext('2d');
var gradient = timeCtx.createLinearGradient(0, 0, 0, 280);
gradient.addColorStop(0, 'rgba(166,227,161,0.4)');
gradient.addColorStop(1, 'rgba(166,227,161,0.02)');

new Chart(timeCtx, {
    type: 'line',
    data: {
        labels: [${timelineLabels}],
        datasets: [{
            label: 'Cumulative Completions',
            data: [${timelineValues}],
            borderColor: '#a6e3a1',
            borderWidth: 2.5,
            backgroundColor: gradient,
            fill: true,
            lineTension: 0.35,
            pointRadius: 0,
            pointHoverRadius: 6,
            pointHoverBackgroundColor: '#a6e3a1',
            pointHoverBorderColor: '#fff',
            pointHoverBorderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: {
            duration: 1500,
            easing: 'easeOutQuart'
        },
        hover: {
            intersect: false,
            mode: 'index'
        },
        scales: {
            xAxes: [{
                gridLines: { color: 'rgba(69,71,90,0.3)', drawBorder: false },
                ticks: { 
                    fontColor: '#6c7086', 
                    fontSize: 10,
                    maxRotation: 45,
                    maxTicksLimit: 10
                }
            }],
            yAxes: [{
                gridLines: { color: 'rgba(69,71,90,0.3)', drawBorder: false },
                ticks: { fontColor: '#6c7086', fontSize: 10, beginAtZero: true },
                scaleLabel: {
                    display: true,
                    labelString: 'Endpoints Completed',
                    fontColor: '#6c7086',
                    fontSize: 11
                }
            }]
        },
        legend: { display: false },
        tooltips: {
            backgroundColor: '#1e1e2e',
            titleFontColor: '#cdd6f4',
            bodyFontColor: '#a6e3a1',
            borderColor: '#313244',
            borderWidth: 1,
            cornerRadius: 8,
            xPadding: 10,
            yPadding: 10
        }
    }
});
</script>
</body>
</html>
"@
}

# ─── Load XAML ────────────────────────────────────────────────────────────────
$reader = New-Object System.Xml.XmlNodeReader $XAML
$window = [Windows.Markup.XamlReader]::Load($reader)

$XAML.SelectNodes("//*[@*[contains(translate(name(),'x','X'),'Name')]]") | ForEach-Object {
    Set-Variable -Name ($_.Name) -Value $window.FindName($_.Name) -Scope Script
}

# ─── API Helper Functions ─────────────────────────────────────────────────────

function Get-BigFixCredential {
    $secPass = $txtPass.SecurePassword
    return New-Object System.Management.Automation.PSCredential($txtUser.Text, $secPass)
}

function Invoke-BigFixAPI {
    param([string]$Endpoint)
    
    $uri = "$($txtServer.Text.TrimEnd('/'))$($script:Config.ApiBase)$Endpoint"
    $cred = Get-BigFixCredential
    
    try {
        if (-not ([System.Management.Automation.PSTypeName]'TrustAllCertsPolicy').Type) {
            Add-Type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(ServicePoint sp, X509Certificate cert, WebRequest req, int problem) { return true; }
}
"@
        }
        [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
        
        $response = Invoke-RestMethod -Uri $uri -Credential $cred -Method Get -ContentType "application/xml"
        return $response
    }
    catch {
        throw "API Error: $($_.Exception.Message)"
    }
}

# ─── Data Processing ──────────────────────────────────────────────────────────

function Get-ActionStatus {
    param([string]$ActionId)
    
    $lblStatus.Text = "Fetching action $ActionId status..."
    $window.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
    
    try {
        $actionInfo = Invoke-BigFixAPI "/action/$ActionId"
        $script:ActionTitle = $actionInfo.BES.SingleAction.Title
    } catch {
        $script:ActionTitle = "(unknown)"
    }
    
    $statusData = Invoke-BigFixAPI "/action/$ActionId/status"
    
    return Parse-StatusData -StatusData $statusData
}

function Parse-StatusData {
    param($StatusData)
    
    $endpoints = @()
    $statusCounts = @{
        Fixed = 0; Failed = 0; Running = 0; Pending = 0; NotRelevant = 0; Expired = 0; Other = 0
    }
    
    $computers = $StatusData.BESAPI.ActionResults.Computer
    if (-not $computers) { $computers = $StatusData.SelectNodes("//Computer") }
    
    foreach ($computer in $computers) {
        $name = $computer.Name
        if (-not $name) { $name = $computer.GetAttribute("Name") }
        $status = $computer.Status
        if (-not $status) { $status = ($computer.SelectSingleNode("Status")).'#text' }
        
        $mappedStatus = switch -Wildcard ($status) {
            "*Fixed*"        { "Fixed"; $statusCounts.Fixed++; break }
            "*Failed*"       { "Failed"; $statusCounts.Failed++; break }
            "*Running*"      { "Running"; $statusCounts.Running++; break }
            "*Evaluating*"   { "Running"; $statusCounts.Running++; break }
            "*Waiting*"      { "Pending"; $statusCounts.Pending++; break }
            "*Pending*"      { "Pending"; $statusCounts.Pending++; break }
            "*Not Relevant*" { "Not Relevant"; $statusCounts.NotRelevant++; break }
            "*Expired*"      { "Expired"; $statusCounts.Expired++; break }
            default          { $status; $statusCounts.Other++; break }
        }
        
        $endpoints += [PSCustomObject]@{
            ComputerName = $name
            Status       = $mappedStatus
            StartTime    = $computer.StartTime
            EndTime      = $computer.EndTime
            ApplyCount   = $computer.ApplyCount
            RetryCount   = $computer.RetryCount
        }
    }
    
    return @{
        Endpoints    = $endpoints
        StatusCounts = $statusCounts
        Total        = $endpoints.Count
    }
}

# ─── Timeline Data Builder ────────────────────────────────────────────────────

function Get-TimelineData {
    param($Endpoints)
    
    $completed = $Endpoints | Where-Object { $_.EndTime -and $_.Status -eq "Fixed" } | 
                 Sort-Object { [datetime]$_.EndTime }
    
    if ($completed.Count -lt 2) {
        return @{
            Labels = @("Start", "Now")
            Values = @(0, 0)
        }
    }
    
    $minTime = [datetime]$completed[0].EndTime
    $maxTime = [datetime]$completed[-1].EndTime
    $timeSpan = ($maxTime - $minTime)
    
    # Create ~20 time buckets
    $bucketCount = [Math]::Min(20, $completed.Count)
    $bucketSize = $timeSpan.TotalMinutes / $bucketCount
    
    $labels = @()
    $values = @()
    $cumulative = 0
    
    for ($i = 0; $i -le $bucketCount; $i++) {
        $bucketEnd = $minTime.AddMinutes($i * $bucketSize)
        $label = $bucketEnd.ToString("MM/dd HH:mm")
        
        $inBucket = ($completed | Where-Object { [datetime]$_.EndTime -le $bucketEnd }).Count
        
        $labels += $label
        $values += $inBucket
    }
    
    return @{
        Labels = $labels
        Values = $values
    }
}

# ─── Demo Data Generator ─────────────────────────────────────────────────────

function Get-DemoData {
    $statuses = @('Fixed','Fixed','Fixed','Fixed','Fixed','Fixed','Fixed',
                  'Failed','Failed','Running','Running','Running',
                  'Pending','Pending','Not Relevant','Not Relevant','Expired')
    
    $prefixes = @('WKS','SRV','LAP','DTK','VDI')
    $sites = @('NYC','CHI','DAL','SEA','ATL','MIA','DEN','BOS','PHX','SFO')
    
    $baseTime = (Get-Date).AddDays(-3)
    $endpoints = @()
    
    for ($i = 1; $i -le 150; $i++) {
        $status = $statuses[(Get-Random -Maximum $statuses.Count)]
        $prefix = $prefixes[(Get-Random -Maximum $prefixes.Count)]
        $site = $sites[(Get-Random -Maximum $sites.Count)]
        $name = "$prefix-$site-$('{0:D4}' -f $i)"
        
        $startOffset = Get-Random -Minimum 0 -Maximum 4320
        $start = $baseTime.AddMinutes($startOffset)
        
        $endTime = $null
        if ($status -eq 'Fixed') {
            $endTime = $start.AddMinutes((Get-Random -Minimum 2 -Maximum 180)).ToString("yyyy-MM-dd HH:mm:ss")
        } elseif ($status -eq 'Failed') {
            $endTime = $start.AddMinutes((Get-Random -Minimum 1 -Maximum 60)).ToString("yyyy-MM-dd HH:mm:ss")
        }
        
        $endpoints += [PSCustomObject]@{
            ComputerName = $name
            Status       = $status
            StartTime    = $start.ToString("yyyy-MM-dd HH:mm:ss")
            EndTime      = $endTime
            ApplyCount   = if ($status -eq 'Fixed') { (Get-Random -Minimum 1 -Maximum 4).ToString() } else { "0" }
            RetryCount   = if ($status -eq 'Failed') { (Get-Random -Minimum 1 -Maximum 5).ToString() } else { "0" }
        }
    }
    
    $statusCounts = @{
        Fixed       = ($endpoints | Where-Object Status -eq 'Fixed').Count
        Failed      = ($endpoints | Where-Object Status -eq 'Failed').Count
        Running     = ($endpoints | Where-Object Status -eq 'Running').Count
        Pending     = ($endpoints | Where-Object Status -eq 'Pending').Count
        NotRelevant = ($endpoints | Where-Object Status -eq 'Not Relevant').Count
        Expired     = ($endpoints | Where-Object Status -eq 'Expired').Count
        Other       = 0
    }
    
    return @{
        Endpoints    = $endpoints
        StatusCounts = $statusCounts
        Total        = $endpoints.Count
    }
}

# ─── Dashboard Update ─────────────────────────────────────────────────────────

function Update-Dashboard {
    param($Data, $ActionLabel)
    
    $script:CurrentData = $Data
    $lblActionName.Text = "Action: $ActionLabel"
    
    # Completion %
    $relevant = $Data.Total - $Data.StatusCounts.NotRelevant
    $completionPct = if ($relevant -gt 0) { [math]::Round(($Data.StatusCounts.Fixed / $relevant) * 100, 1) } else { 0 }
    
    # Build timeline data
    $timeline = Get-TimelineData -Endpoints $Data.Endpoints
    
    # Generate and load chart HTML
    $html = Get-ChartHTML -StatusCounts $Data.StatusCounts -Total $Data.Total -TimelineData $timeline -CompletionPct $completionPct
    
    # Write to temp file (WebBrowser needs a file for IE11 compat)
    $tempFile = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), "bigfix_charts.html")
    [System.IO.File]::WriteAllText($tempFile, $html, [System.Text.Encoding]::UTF8)
    $wbCharts.Navigate($tempFile)
    
    # Populate grid
    $dgEndpoints.ItemsSource = $Data.Endpoints
    
    $btnRefresh.IsEnabled = $true
    $btnExport.IsEnabled = $true
    $lblLastRefresh.Text = "Last refresh: $(Get-Date -Format 'HH:mm:ss')"
}

# ─── Event Handlers ───────────────────────────────────────────────────────────

$btnDemo.Add_Click({
    $lblStatus.Text = "Generating demo data..."
    $window.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
    
    $data = Get-DemoData
    Update-Dashboard -Data $data -ActionLabel "DEMO - Windows 11 24H2 Feature Update (150 endpoints)"
    $txtActionId.Text = "DEMO-12345"
    $lblStatus.Text = "[OK] Demo data loaded -- 150 simulated endpoints"
})

$btnConnect.Add_Click({
    try {
        $lblStatus.Text = "Testing connection to $($txtServer.Text)..."
        $window.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
        
        $result = Invoke-BigFixAPI "/login"
        $lblStatus.Text = "[OK] Connected to BigFix server"
        $btnFetch.IsEnabled = $true
    }
    catch {
        $lblStatus.Text = "[ERR] Connection failed: $($_.Exception.Message)"
    }
})

$btnFetch.Add_Click({
    $actionId = $txtActionId.Text.Trim()
    if (-not $actionId) {
        $lblStatus.Text = "[!] Enter an Action ID"
        return
    }
    
    try {
        $data = Get-ActionStatus -ActionId $actionId
        Update-Dashboard -Data $data -ActionLabel "$($script:ActionTitle) (Action $actionId)"
        $lblStatus.Text = "[OK] Loaded $($data.Total) endpoints for Action $actionId"
    }
    catch {
        $lblStatus.Text = "[ERR] Error: $($_.Exception.Message)"
    }
})

$btnRefresh.Add_Click({
    $btnFetch.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
})

$btnExport.Add_Click({
    if (-not $script:CurrentData) { return }
    
    $saveDialog = New-Object Microsoft.Win32.SaveFileDialog
    $saveDialog.Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*"
    $saveDialog.FileName = "BigFix_Action_$($txtActionId.Text)_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
    
    if ($saveDialog.ShowDialog() -eq $true) {
        $script:CurrentData.Endpoints | Export-Csv -Path $saveDialog.FileName -NoTypeInformation
        $lblStatus.Text = "[OK] Exported to $($saveDialog.FileName)"
    }
})

$txtActionId.Add_KeyDown({
    if ($_.Key -eq [System.Windows.Input.Key]::Return) {
        $btnFetch.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
})

# ─── Launch ───────────────────────────────────────────────────────────────────
$window.ShowDialog() | Out-Null
